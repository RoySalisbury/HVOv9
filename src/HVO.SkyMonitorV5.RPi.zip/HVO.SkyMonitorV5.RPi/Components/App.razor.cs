namespace HVO.SkyMonitorV5.RPi.Components;

/// <summary>
/// Root component for the SkyMonitor v5 Raspberry Pi host.
/// </summary>
public sealed partial class App
{
}
