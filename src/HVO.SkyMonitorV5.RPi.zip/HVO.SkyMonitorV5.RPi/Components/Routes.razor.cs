namespace HVO.SkyMonitorV5.RPi.Components;

/// <summary>
/// Configures routing for the SkyMonitor v5 web UI.
/// </summary>
public sealed partial class Routes
{
}
