using HVO.SkyMonitorV5.RPi.Cameras.MockCamera;

namespace HVO.SkyMonitorV5.RPi.Data;

public sealed record ConstellationStar(string Name, Star Star);
